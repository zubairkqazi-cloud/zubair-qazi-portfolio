Zubair Qazi Portfolio

This is a static website. Upload the contents of this folder to a GitHub repository, then import that repository into Vercel to deploy.

Entry file: index.html
Before public submission, add verified project screenshots, repository/demo links, and contact details.
